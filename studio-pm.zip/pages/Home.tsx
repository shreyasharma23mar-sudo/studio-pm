
import React from 'react';
import { PROJECTS, SERVICES } from '../constants';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <main className="w-full">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center bg-[#1B2E24] overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=1920"
            alt="Studio PM - Featured Architecture"
            className="w-full h-full object-cover opacity-50 scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#1B2E24]/60 via-[#1B2E24]/30 to-[#1B2E24]/90" />
        </div>

        <div className="relative z-10 container mx-auto px-6 md:px-12 text-white">
          <div className="max-w-5xl">
            <p className="text-[#E7C665] uppercase tracking-[0.4em] text-xs font-bold mb-8 fade-in">
              Authenticity • Research • Rigor
            </p>
            <h1 className="text-5xl md:text-8xl lg:text-[10rem] font-bold mb-8 leading-[0.85] tracking-tighter fade-in" style={{ animationDelay: '0.2s' }}>
              Designing Spaces<br />That Shape Tomorrow.
            </h1>
            <div className="flex flex-col md:flex-row md:items-end gap-8 fade-in" style={{ animationDelay: '0.3s' }}>
              <p className="text-sm md:text-base uppercase tracking-widest text-gray-300 max-w-sm">
                A Mumbai-based architecture & interior design studio led by Priyank Mehta.
              </p>
              <Link
                to="/contact"
                className="inline-block bg-[#E7C665] text-[#1B2E24] px-12 py-5 text-sm font-bold uppercase tracking-widest hover:bg-white transition-all transform hover:scale-105"
              >
                Start Your Project
              </Link>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-12 right-12 hidden md:flex flex-col items-end">
            <div className="w-24 h-px bg-[#E7C665]/30 mb-4" />
            <p className="text-[10px] uppercase tracking-widest text-[#E7C665]/60">Est. Mumbai</p>
        </div>
      </section>

      {/* Diversity Section - Sectors */}
      <section className="py-24 md:py-40 bg-[#F4F1EA]">
        <div className="container mx-auto px-6 md:px-12">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-32 items-start">
                <div className="sticky top-32">
                    <span className="text-[#E7C665] font-bold text-sm uppercase tracking-widest">Our Breadth</span>
                    <h2 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tighter mt-6 mb-10 leading-[0.9]">
                      Architecture <br />Without Borders.
                    </h2>
                    <p className="text-base md:text-lg editorial-text text-[#1B2E24]/80 max-w-lg mb-12">
                        From luxury villas and high-end residential interiors to corporate offices and boutique hospitality projects, Studio PM brings architectural rigor to every scale. We believe in research-driven design that prioritizes site context and human experience.
                    </p>
                    <Link to="/projects" className="inline-block text-xs font-bold uppercase border-b-2 border-[#1B2E24] pb-2 hover:text-[#E7C665] hover:border-[#E7C665] transition-all">
                        Explore Our Portfolio
                    </Link>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-12 lg:pt-0">
                    <div className="space-y-6">
                      <img src="https://images.unsplash.com/photo-1550966841-3ee3ad359051?auto=format&fit=crop&q=80&w=600" className="w-full aspect-[4/5] object-cover" alt="Hospitality" />
                      <img src="https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=600" className="w-full aspect-square object-cover" alt="Villa" />
                    </div>
                    <div className="space-y-6 md:mt-24">
                      <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=600" className="w-full aspect-square object-cover" alt="Office" />
                      <img src="https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?auto=format&fit=crop&q=80&w=600" className="w-full aspect-[4/5] object-cover" alt="Retail" />
                    </div>
                </div>
            </div>
        </div>
      </section>

      {/* Featured Juhu Residence */}
      <section className="py-24 md:py-40 bg-[#1B2E24] text-white">
        <div className="container mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            <div className="col-span-12 lg:col-span-7 relative group">
                <img src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1200" alt="Juhu Residence" className="w-full h-[500px] md:h-[700px] object-cover" />
                <div className="absolute -bottom-8 -right-4 md:-right-8 bg-[#E7C665] p-8 md:p-12 shadow-xl">
                    <span className="text-[10px] uppercase font-bold text-[#1B2E24] tracking-widest block mb-2">Recognized Narrative</span>
                    <h4 className="text-xl md:text-2xl font-bold text-[#1B2E24]">Elle Decor India</h4>
                </div>
            </div>
            <div className="col-span-12 lg:col-span-5 lg:pl-12">
                <span className="text-[#E7C665] font-bold text-xs uppercase tracking-widest">Iconic Project</span>
                <h2 className="text-5xl md:text-6xl font-bold tracking-tighter mt-6 mb-8 leading-none">A Timeless <br />Home in Juhu.</h2>
                <p className="text-base text-gray-400 leading-relaxed editorial-text mb-12">
                    A project that defines our residential philosophy. We balanced modernist silhouettes with tactile materials to create a sanctuary that breathes within the urban fabric of Mumbai. Every detail was crafted to endure.
                </p>
                <Link to="/blog" className="inline-flex items-center space-x-6 group">
                    <span className="bg-white text-[#1B2E24] px-8 py-5 text-xs font-bold uppercase tracking-widest group-hover:bg-[#E7C665] transition-all">
                        Read the Story
                    </span>
                    <div className="w-12 h-px bg-[#E7C665] group-hover:w-24 transition-all" />
                </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Services Snapshot */}
      <section className="py-24 md:py-40 bg-[#F4F1EA]">
        <div className="container mx-auto px-6 md:px-12">
            <div className="flex flex-col md:flex-row justify-between items-baseline mb-20 gap-8">
                <h2 className="text-5xl md:text-8xl font-bold tracking-tighter leading-none">Holistic <br />Expertise.</h2>
                <Link to="/services" className="text-xs font-bold uppercase tracking-widest border-b-2 border-[#E7C665] pb-2 hover:border-[#1B2E24] transition-all">
                  View All Services
                </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                {SERVICES.slice(0, 3).map((service) => (
                    <div key={service.id} className="group">
                        <div className="aspect-[3/4] overflow-hidden mb-8 bg-white">
                            <img src={service.image} className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000 group-hover:scale-105" alt={service.title} />
                        </div>
                        <div className="flex justify-between items-start mb-4">
                          <h4 className="text-2xl font-bold">{service.title}</h4>
                          <span className="text-[10px] font-bold text-[#E7C665]">0{SERVICES.indexOf(service) + 1}</span>
                        </div>
                        <p className="text-sm text-[#1B2E24]/60 leading-relaxed max-w-xs">{service.description}</p>
                    </div>
                ))}
            </div>
        </div>
      </section>
    </main>
  );
};

export default Home;
