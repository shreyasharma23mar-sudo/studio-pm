
import React from 'react';

interface LegalProps {
    title: string;
}

const Legal: React.FC<LegalProps> = ({ title }) => {
  return (
    <main className="pt-32 bg-[#F4F1EA] min-h-screen pb-32">
      <div className="container mx-auto px-6 md:px-12 max-w-4xl">
        <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 text-[#1B2E24]">{title}</h1>
        <div className="w-24 h-1 bg-[#E7C665] mb-16" />

        <div className="space-y-12 text-[#1B2E24]/80 editorial-text">
            <section>
                <h2 className="text-2xl font-bold text-[#1B2E24] mb-6 uppercase tracking-widest">Introduction</h2>
                <p>Studio PM respects your privacy and is committed to protecting it through our compliance with this policy. This policy describes the types of information we may collect from you or that you may provide when you visit our website.</p>
            </section>

            <section>
                <h2 className="text-2xl font-bold text-[#1B2E24] mb-6 uppercase tracking-widest">Data Protection</h2>
                <p>We implement a variety of security measures to maintain the safety of your personal information when you enter, submit, or access your personal information. Our studio takes data sovereignty seriously and ensures all client communications remain confidential.</p>
            </section>

            <section>
                <h2 className="text-2xl font-bold text-[#1B2E24] mb-6 uppercase tracking-widest">Copyright & IP</h2>
                <p>All architectural designs, imagery, and project narratives featured on this website are the intellectual property of Studio PM. Visuals from the Juhu Residence project featured in Elle Decor India are protected by copyright laws.</p>
            </section>
        </div>
      </div>
    </main>
  );
};

export default Legal;
