
import React from 'react';
import { useParams } from 'react-router-dom';

const LandingPage: React.FC = () => {
  const { type } = useParams<{ type: string }>();

  const contentMap: Record<string, any> = {
    'luxury-mumbai': {
        title: 'Luxury Home Interiors – Mumbai',
        subtitle: 'Bespoke residences that define the city\'s elite lifestyle.',
        painPoints: ['Overwhelmed by choices?', 'Lack of project cohesion?', 'Communication gaps with contractors?'],
        solutions: ['Curated material selections', 'Unified architectural vision', 'Strict design oversight'],
        bg: 'https://picsum.photos/id/101/1600/900'
    },
    'modern-residential': {
        title: 'Modern Residential Design',
        subtitle: 'Architectural honesty meets contemporary comfort.',
        painPoints: ['Dark, cluttered spaces?', 'Outdated layouts?', 'Wasted spatial potential?'],
        solutions: ['Natural light optimization', 'Open-plan fluidity', 'Smart storage integration'],
        bg: 'https://picsum.photos/id/102/1600/900'
    },
    'turnkey-solutions': {
        title: 'Turnkey Interior Solutions',
        subtitle: 'From blueprint to styling. Effortless transformation.',
        painPoints: ['Construction delays?', 'Quality control issues?', 'Vague budgeting?'],
        solutions: ['Fixed timelines', 'Rigorous quality auditing', 'Transparent commercial management'],
        bg: 'https://picsum.photos/id/103/1600/900'
    }
  };

  const data = contentMap[type || 'luxury-mumbai'] || contentMap['luxury-mumbai'];

  return (
    <main className="bg-[#F4F1EA]">
        {/* Hero */}
        <section className="relative h-[80vh] flex items-center bg-[#1B2E24] overflow-hidden">
            <img src={data.bg} className="absolute inset-0 w-full h-full object-cover opacity-50" alt="Landing Hero" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#1B2E24] to-transparent" />
            <div className="container mx-auto px-6 relative z-10 text-white max-w-4xl">
                <span className="text-[#E7C665] font-bold uppercase tracking-[0.3em] text-xs mb-6 block">Campaign Focus</span>
                <h1 className="text-5xl md:text-8xl font-bold tracking-tighter mb-8 leading-tight">{data.title}</h1>
                <p className="text-xl italic text-gray-300 mb-12">{data.subtitle}</p>
                <a href="#capture" className="bg-[#E7C665] text-[#1B2E24] px-10 py-5 font-bold uppercase tracking-widest hover:bg-white transition-all">Get Your Design Guide</a>
            </div>
        </section>

        {/* Challenges & Solutions */}
        <section className="py-24 container mx-auto px-6 md:px-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
                <div className="bg-white p-12 border-t-4 border-red-800">
                    <h3 className="text-2xl font-bold mb-8 uppercase tracking-widest text-red-800">The Challenges</h3>
                    <ul className="space-y-6">
                        {data.painPoints.map((p: string) => (
                            <li key={p} className="flex items-start space-x-4">
                                <span className="text-red-800 font-bold">✕</span>
                                <span className="text-lg editorial-text">{p}</span>
                            </li>
                        ))}
                    </ul>
                </div>
                <div className="bg-[#1B2E24] p-12 border-t-4 border-[#E7C665] text-white">
                    <h3 className="text-2xl font-bold mb-8 uppercase tracking-widest text-[#E7C665]">The Studio PM Solution</h3>
                    <ul className="space-y-6">
                        {data.solutions.map((s: string) => (
                            <li key={s} className="flex items-start space-x-4">
                                <span className="text-[#E7C665] font-bold">✓</span>
                                <span className="text-lg editorial-text">{s}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </section>

        {/* Form Capture */}
        <section id="capture" className="py-24 bg-[#E7C665]">
            <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
                <div>
                    <h2 className="text-4xl md:text-6xl font-bold tracking-tighter text-[#1B2E24] mb-8">Secure your design consultation.</h2>
                    <p className="text-[#1B2E24]/70 mb-8 editorial-text">Our principal architects personally review all inquiries. Take the first step toward a home that truly reflects who you are.</p>
                    <div className="p-8 bg-white/30 backdrop-blur italic border-l-4 border-[#1B2E24]">
                        "Their approach to Juhu Residence was revolutionary. They understood what we needed before we did."
                        <span className="block mt-4 not-italic font-bold text-xs uppercase tracking-widest">— Happy Client</span>
                    </div>
                </div>
                <div className="bg-[#1B2E24] p-12 shadow-2xl">
                    <form className="space-y-6">
                        <input className="w-full bg-white/10 border border-white/20 p-4 text-white outline-none focus:border-[#E7C665]" placeholder="Your Name" />
                        <input className="w-full bg-white/10 border border-white/20 p-4 text-white outline-none focus:border-[#E7C665]" placeholder="Email Address" />
                        <input className="w-full bg-white/10 border border-white/20 p-4 text-white outline-none focus:border-[#E7C665]" placeholder="Phone Number" />
                        <textarea className="w-full bg-white/10 border border-white/20 p-4 text-white outline-none focus:border-[#E7C665] resize-none" rows={4} placeholder="Briefly describe your project..." />
                        <button className="w-full bg-[#E7C665] text-[#1B2E24] font-bold py-5 uppercase tracking-widest hover:bg-white transition-all">Submit Inquiry</button>
                    </form>
                </div>
            </div>
        </section>
    </main>
  );
};

export default LandingPage;
