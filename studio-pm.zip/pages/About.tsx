
import React from 'react';

const About: React.FC = () => {
  return (
    <main className="pt-32 bg-[#F4F1EA]">
      {/* Header */}
      <section className="container mx-auto px-6 md:px-12 pb-24 border-b border-[#1B2E24]/10">
        <h1 className="text-7xl md:text-[10rem] font-bold tracking-tighter leading-[0.8] mb-12">
          The <br /><span className="text-[#E7C665]">Visionary.</span>
        </h1>
        <div className="grid grid-cols-12 gap-8 items-center">
          <div className="col-span-12 md:col-span-6">
            <p className="text-2xl font-medium leading-relaxed italic text-[#1B2E24]">
              Studio PM is led by architect Priyank Mehta, whose design philosophy is rooted in authenticity and architectural rigor.
            </p>
          </div>
          <div className="col-span-12 md:col-span-5 md:offset-col-1">
             <p className="text-sm text-[#1B2E24]/70 leading-relaxed editorial-text">
                Based in Mumbai, our studio operates on the belief that great design is born from deep research and a rejection of fleeting trends. We prioritize the experience of the inhabitant, creating spaces that are both intellectually stimulating and emotionally resonant.
             </p>
          </div>
        </div>
      </section>

      {/* Studio Culture & Team */}
      <section className="grid grid-cols-1 md:grid-cols-2 min-h-screen">
        <div className="bg-[#1B2E24] p-12 md:p-24 flex flex-col justify-center text-white">
            <span className="text-[#E7C665] font-bold text-xs uppercase tracking-widest mb-6">Collaborative Spirit</span>
            <h2 className="text-4xl md:text-6xl font-bold mb-10 leading-none tracking-tighter">Research <br />Over Trends.</h2>
            <div className="space-y-8 text-sm text-gray-300 editorial-text max-w-md">
                <p>At Studio PM, we don't start with aesthetics. We start with ideas. Our team fosters a culture of inquiry where site analysis, material experimentation, and lifestyle research form the foundation of every blueprint.</p>
                <p>Led by Priyank's precision, our collaborative environment ensures that every project benefits from a collective pool of expertise—from technical engineering to bespoke interior styling.</p>
            </div>
        </div>
        <div className="relative overflow-hidden">
            <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=1000" alt="Studio PM Collaborative Culture" className="w-full h-full object-cover grayscale" />
            <div className="absolute inset-0 bg-[#1B2E24]/20" />
        </div>
      </section>

      {/* Leadership Section */}
      <section className="py-32 container mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
            <div className="col-span-12 md:col-span-5 order-2 md:order-1">
                <h3 className="text-4xl font-bold tracking-tighter mb-8">Priyank Mehta</h3>
                <p className="text-sm text-[#1B2E24]/70 editorial-text mb-6">
                    With years of experience across diverse architectural landscapes, Priyank has curated a portfolio that speaks of spatial intelligence and material honesty. His leadership at Studio PM is marked by a personal involvement in every project, ensuring the studio's standards of rigor are met without compromise.
                </p>
                <div className="w-12 h-px bg-[#E7C665] mb-6" />
                <p className="text-xs font-bold uppercase tracking-widest">Lead Architect & Founder</p>
            </div>
            <div className="col-span-12 md:col-span-7 order-1 md:order-2 flex justify-center md:justify-end">
                 <div className="relative group">
                    <div className="absolute inset-0 bg-[#E7C665] translate-x-4 translate-y-4 group-hover:translate-x-2 group-hover:translate-y-2 transition-transform duration-500"></div>
                    <div className="relative w-64 h-64 md:w-96 md:h-96 overflow-hidden border-8 border-white shadow-2xl bg-white">
                        <img 
                            src="https://media.licdn.com/dms/image/v2/C4D03AQGqmyWBkmHzTg/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1517470987697?e=1770249600&v=beta&t=3mDw4-_fyanseQWysGhoLvakV8n3X6eIXc8JtPLfm-w" 
                            alt="Priyank Mehta - Founder & Lead Architect" 
                            className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700 scale-110" 
                        />
                    </div>
                 </div>
            </div>
        </div>
      </section>
    </main>
  );
};

export default About;
