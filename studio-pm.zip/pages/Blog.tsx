
import React from 'react';
import { BLOG_POSTS } from '../constants';

const Blog: React.FC = () => {
  return (
    <main className="pt-32 bg-[#F4F1EA] min-h-screen pb-32">
      <section className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
            <h1 className="text-7xl md:text-9xl font-bold tracking-tighter leading-none">Journal<span className="text-[#E7C665]">.</span></h1>
            <div className="flex space-x-4">
                {['All', 'Press', 'Insights', 'Philosophy'].map(cat => (
                    <button key={cat} className="px-6 py-2 border border-[#1B2E24]/20 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-[#1B2E24] hover:text-white transition-all">
                        {cat}
                    </button>
                ))}
            </div>
        </div>

        {/* Featured Post - Full Width */}
        <article className="relative h-[70vh] group overflow-hidden mb-24 cursor-pointer">
            <img src={BLOG_POSTS[0].image} alt={BLOG_POSTS[0].title} className="w-full h-full object-cover grayscale-[0.3] group-hover:grayscale-0 group-hover:scale-105 transition-all duration-1000" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1B2E24] via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 p-12 text-white max-w-3xl">
                <span className="inline-block bg-[#E7C665] text-[#1B2E24] px-4 py-1 text-[10px] font-bold uppercase tracking-widest mb-6">{BLOG_POSTS[0].category}</span>
                <h2 className="text-4xl md:text-6xl font-bold mb-6 tracking-tighter">{BLOG_POSTS[0].title}</h2>
                <p className="text-lg text-gray-300 leading-relaxed editorial-text mb-8">{BLOG_POSTS[0].excerpt}</p>
                <div className="flex items-center space-x-4">
                    <span className="text-xs uppercase tracking-widest font-bold">Read Article</span>
                    <div className="w-12 h-px bg-[#E7C665]" />
                </div>
            </div>
        </article>

        {/* Grid Posts */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {[...BLOG_POSTS, ...BLOG_POSTS].map((post, idx) => (
                <article key={post.id + idx} className="group">
                    <div className="aspect-square overflow-hidden mb-6 bg-white">
                        <img src={post.image} alt={post.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" />
                    </div>
                    <div className="space-y-4">
                         <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest text-[#E7C665]">
                            <span>{post.category}</span>
                            <span className="text-[#1B2E24]/40">{post.date}</span>
                        </div>
                        <h3 className="text-2xl font-bold leading-tight group-hover:text-[#E7C665] transition-colors">{post.title}</h3>
                        <p className="text-sm text-[#1B2E24]/60 leading-relaxed line-clamp-2">{post.excerpt}</p>
                        <button className="text-[10px] font-bold uppercase border-b-2 border-[#1B2E24] pb-1">View Story</button>
                    </div>
                </article>
            ))}
        </div>
      </section>
    </main>
  );
};

export default Blog;
