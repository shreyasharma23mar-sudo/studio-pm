
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const links = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Projects', path: '/projects' },
    { name: 'Services', path: '/services' },
    { name: 'Blog', path: '/blog' },
    { name: 'Contact', path: '/contact' },
  ];

  const isDarkText = location.pathname === '/' ? isScrolled : true;

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-[#F4F1EA]/95 backdrop-blur-md py-4 shadow-sm' : 'bg-transparent py-8'}`}>
      <div className="container mx-auto px-6 md:px-12 flex justify-between items-center">
        <Link to="/" className={`text-3xl md:text-4xl font-extrabold tracking-tighter brand-font transition-colors ${isDarkText ? 'text-[#1B2E24]' : 'text-white'}`}>
          STUDIO PM<span className="text-[#E7C665]">.</span>
        </Link>

        <div className="hidden md:flex space-x-10 items-center">
          {links.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`text-sm font-medium tracking-widest uppercase transition-all duration-300 hover:text-[#E7C665] ${isDarkText ? 'text-[#1B2E24]' : 'text-white'} ${location.pathname === link.path ? 'border-b border-[#E7C665]' : ''}`}
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/contact"
            className="bg-[#E7C665] text-[#1B2E24] px-6 py-2 text-xs font-bold uppercase tracking-widest hover:bg-white transition-colors"
          >
            Inquire
          </Link>
        </div>

        <button className="md:hidden text-[#1B2E24]">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
