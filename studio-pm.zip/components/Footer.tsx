
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#1B2E24] text-white pt-24 pb-12">
      <div className="container mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-20 border-b border-white/10">
          <div className="md:col-span-5">
            <h2 className="text-4xl md:text-6xl font-bold leading-none brand-font mb-8">
              Let's create your <br /><span className="text-[#E7C665]">Timeless Home.</span>
            </h2>
            <Link
              to="/contact"
              className="inline-block bg-[#E7C665] text-[#1B2E24] px-10 py-5 text-sm font-bold uppercase tracking-widest hover:bg-white transition-all transform hover:-translate-y-1"
            >
              Start Your Project
            </Link>
          </div>

          <div className="md:col-span-3 md:offset-col-1">
            <h4 className="text-[#E7C665] uppercase tracking-widest text-xs font-bold mb-6">Explore</h4>
            <ul className="space-y-4">
              <li><Link to="/about" className="hover:text-[#E7C665] transition-colors">Studio Story</Link></li>
              <li><Link to="/services" className="hover:text-[#E7C665] transition-colors">Our Expertise</Link></li>
              <li><Link to="/blog" className="hover:text-[#E7C665] transition-colors">Elle Decor Feature</Link></li>
              <li><Link to="/privacy" className="hover:text-[#E7C665] transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>

          <div className="md:col-span-3">
            <h4 className="text-[#E7C665] uppercase tracking-widest text-xs font-bold mb-6">Contact</h4>
            <p className="text-sm text-gray-400 mb-4 leading-relaxed">
              95 Ratnajyot Industrial Estate,<br />
              Irla Gauthan Road, Vile Parle West,<br />
              Mumbai 400056
            </p>
            <p className="text-sm text-gray-400 mb-2">022 262000084</p>
            <p className="text-sm text-gray-400">contact@studiopm.in</p>
          </div>
        </div>

        <div className="pt-12 flex flex-col md:flex-row justify-between items-center text-[10px] uppercase tracking-[0.2em] text-gray-500">
          <p>© 2024 Studio PM. All Rights Reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Instagram</a>
            <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
            <a href="#" className="hover:text-white transition-colors">Pinterest</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
