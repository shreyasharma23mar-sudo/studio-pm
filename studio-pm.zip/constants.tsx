
import { Project, Service, BlogPost } from './types';

export const COLORS = {
  primary: '#1B2E24', // Deep Green
  accent: '#E7C665',  // Soft Yellow
  neutral: '#F4F1EA', // Bone White
};

export const PROJECTS: Project[] = [
  {
    id: 'res-juhu',
    title: 'A Timeless Home',
    category: 'Residential',
    image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=1200',
    description: 'A Juhu residence featured in Elle Decor India, showcasing minimalist sensibilities and opulent materials.'
  },
  {
    id: 'hosp-bistro',
    title: 'The Urban Bistro',
    category: 'Hospitality',
    image: 'https://images.unsplash.com/photo-1550966841-3ee3ad359051?auto=format&fit=crop&q=80&w=1200',
    description: 'Restaurant architecture focusing on intimate lighting and raw material honesty.'
  },
  {
    id: 'off-nexus',
    title: 'Nexus Corporate HQ',
    category: 'Office',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1200',
    description: 'Office design & planning centered around collaborative agility and natural lighting.'
  },
  {
    id: 'villa-alibaug',
    title: 'Coastal Villa',
    category: 'Villa',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1200',
    description: 'A luxury villa in Alibaug blending seamless indoor-outdoor architectural flow.'
  },
  {
    id: 'ret-boutique',
    title: 'Vogue Boutique',
    category: 'Retail',
    image: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?auto=format&fit=crop&q=80&w=1200',
    description: 'High-end retail space design where architecture meets branding.'
  }
];

export const SERVICES: Service[] = [
  {
    id: 'arch',
    title: 'Architecture Design',
    description: 'From villas to hotels, we design structures that harmonize with their context.',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'interior',
    title: 'Interior Design',
    description: 'Curation of soul-stirring residential and commercial spaces.',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'office',
    title: 'Office Planning',
    description: 'Research-driven spatial layouts for modern productivity and collaboration.',
    image: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'hosp',
    title: 'Hospitality & Hotels',
    description: 'Creating memorable experiences through restaurant and hotel architecture.',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'turnkey',
    title: 'Turnkey Solutions',
    description: 'Complete project management from conceptualization to final styling.',
    image: 'https://images.unsplash.com/photo-1503387762-592dea58ef23?auto=format&fit=crop&q=80&w=800'
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'research-design',
    title: 'The Role of Research in Modern Architecture',
    category: 'Insights',
    date: 'April 2024',
    image: 'https://images.unsplash.com/photo-1497215842964-222b430dc094?auto=format&fit=crop&q=80&w=1200',
    excerpt: 'How Priyank Mehta and the Studio PM team approach site-specific research before sketching.'
  },
  {
    id: 'elle-decor-feature',
    title: 'Juhu Residence: A Study in Timelessness',
    category: 'Press',
    date: 'March 2024',
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1200',
    excerpt: 'The Elle Decor India feature showcases our balance of minimalist sensibilities with opulent materials.'
  }
];
