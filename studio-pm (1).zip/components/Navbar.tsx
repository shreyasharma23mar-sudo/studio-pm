
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const links = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Projects', path: '/projects' },
    { name: 'Services', path: '/services' },
    { name: 'Blog', path: '/blog' },
    { name: 'Contact', path: '/contact' },
  ];

  const isDarkText = location.pathname === '/' ? isScrolled : true;

  return (
    <nav className={`fixed top-0 left-0 w-full z-[100] transition-all duration-500 ${isScrolled ? 'bg-[#F4F1EA]/95 backdrop-blur-md py-4 shadow-sm' : 'bg-transparent py-10'}`}>
      <div className="container mx-auto px-6 md:px-12 flex justify-between items-center">
        <Link to="/" className={`text-4xl md:text-6xl font-black tracking-tighter brand-font transition-colors leading-none ${isDarkText ? 'text-[#1B2E24]' : 'text-white'}`}>
          STUDIO PM<span className="text-[#E7C665]">.</span>
        </Link>

        <div className="hidden lg:flex space-x-12 items-center">
          {links.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`text-xs font-bold tracking-widest uppercase transition-all duration-300 hover:text-[#E7C665] ${isDarkText ? 'text-[#1B2E24]' : 'text-white'} ${location.pathname === link.path ? 'border-b border-[#E7C665]' : ''}`}
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/contact"
            className="bg-[#E7C665] text-[#1B2E24] px-10 py-4 text-xs font-black uppercase tracking-widest hover:bg-[#1B2E24] hover:text-white transition-all transform hover:-translate-y-0.5 shadow-lg"
          >
            Inquire
          </Link>
        </div>

        <button className={`lg:hidden p-2 ${isDarkText ? 'text-[#1B2E24]' : 'text-white'}`}>
          <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 8h16M4 16h16"></path></svg>
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
