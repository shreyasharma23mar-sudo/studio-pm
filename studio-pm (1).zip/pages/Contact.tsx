
import React from 'react';

const Contact: React.FC = () => {
  return (
    <main className="pt-32 bg-[#F4F1EA] min-h-screen">
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[calc(100vh-8rem)]">
        {/* Contact Form Left */}
        <div className="p-12 md:p-24 bg-[#1B2E24] text-white flex flex-col justify-center">
            <h1 className="text-6xl md:text-8xl font-bold tracking-tighter mb-8 leading-none">Connect<span className="text-[#E7C665]">.</span></h1>
            <p className="text-sm text-gray-400 mb-12 max-w-md editorial-text">
                Start a conversation about your next project. We are available for architectural commissions and full-scale interior transformations across Mumbai and beyond.
            </p>

            <form className="space-y-8 max-w-lg">
                <div className="grid grid-cols-2 gap-8">
                    <div className="border-b border-white/20 focus-within:border-[#E7C665] transition-colors pb-2">
                        <label className="block text-[10px] uppercase tracking-widest mb-2 opacity-50">Name</label>
                        <input type="text" className="bg-transparent w-full outline-none text-white font-light" placeholder="Full Name" />
                    </div>
                    <div className="border-b border-white/20 focus-within:border-[#E7C665] transition-colors pb-2">
                        <label className="block text-[10px] uppercase tracking-widest mb-2 opacity-50">Email</label>
                        <input type="email" className="bg-transparent w-full outline-none text-white font-light" placeholder="Email Address" />
                    </div>
                </div>
                <div className="border-b border-white/20 focus-within:border-[#E7C665] transition-colors pb-2">
                    <label className="block text-[10px] uppercase tracking-widest mb-2 opacity-50">Sector Interest</label>
                    <select className="bg-transparent w-full outline-none text-white font-light appearance-none">
                        <option className="bg-[#1B2E24]">Residential Architecture</option>
                        <option className="bg-[#1B2E24]">Hospitality & Restaurants</option>
                        <option className="bg-[#1B2E24]">Office Planning</option>
                        <option className="bg-[#1B2E24]">Luxury Villa Design</option>
                        <option className="bg-[#1B2E24]">Turnkey Solutions</option>
                    </select>
                </div>
                <div className="border-b border-white/20 focus-within:border-[#E7C665] transition-colors pb-2">
                    <label className="block text-[10px] uppercase tracking-widest mb-2 opacity-50">Message</label>
                    <textarea rows={4} className="bg-transparent w-full outline-none text-white font-light resize-none" placeholder="Tell us about your architectural vision..."></textarea>
                </div>
                <button type="submit" className="w-full bg-[#E7C665] text-[#1B2E24] font-bold py-5 uppercase tracking-widest hover:bg-white transition-all transform hover:-translate-y-1">
                    Send Inquiry
                </button>
            </form>
        </div>

        {/* Contact Info Right */}
        <div className="relative flex flex-col lg:flex-row h-full">
            <div className="flex-1 relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&q=80&w=800" alt="Studio PM Office" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-[#E7C665]/20 backdrop-grayscale" />
            </div>
            <div className="lg:absolute lg:right-0 lg:bottom-0 p-12 md:p-16 bg-[#F4F1EA] lg:max-w-md w-full border-l border-t border-[#1B2E24]/10 shadow-2xl">
                <div className="space-y-10">
                    <div>
                        <h4 className="text-[10px] uppercase tracking-widest font-bold text-[#E7C665] mb-4">Studio Location</h4>
                        <p className="text-sm font-medium leading-relaxed">
                            95 Ratnajyot Industrial Estate,<br />
                            Irla Gaothan Road,<br />
                            Vile Parle West,<br />
                            Mumbai 400056, IN
                        </p>
                    </div>
                    <div>
                        <h4 className="text-[10px] uppercase tracking-widest font-bold text-[#E7C665] mb-4">Direct Lines</h4>
                        <p className="text-sm font-medium">contact@studiopm.in</p>
                        <p className="text-sm font-medium mt-2">022 262000084</p>
                    </div>
                    <div className="pt-8 flex space-x-6 border-t border-[#1B2E24]/10">
                         <a href="#" className="text-xs uppercase font-bold tracking-widest hover:text-[#E7C665]">Instagram</a>
                         <a href="#" className="text-xs uppercase font-bold tracking-widest hover:text-[#E7C665]">LinkedIn</a>
                         <a href="#" className="text-xs uppercase font-bold tracking-widest hover:text-[#E7C665]">Pinterest</a>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </main>
  );
};

export default Contact;
