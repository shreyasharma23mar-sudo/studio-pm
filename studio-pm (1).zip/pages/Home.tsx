
import React from 'react';
import { SERVICES } from '../constants';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <main className="w-full bg-[#F4F1EA]">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center bg-[#1B2E24] overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=1920"
            alt="Studio PM - Featured Architecture"
            className="w-full h-full object-cover opacity-40 scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#1B2E24]/80 via-[#1B2E24]/30 to-[#1B2E24]/90" />
        </div>

        <div className="relative z-10 container mx-auto px-6 md:px-12 text-white">
          <div className="max-w-7xl">
            <p className="text-[#E7C665] uppercase tracking-[0.6em] text-[10px] md:text-xs font-black mb-16 fade-in">
              Authenticity • Research • Rigor
            </p>
            <h1 className="text-6xl md:text-8xl lg:text-[11rem] font-black mb-16 leading-[0.98] tracking-tighter fade-in" style={{ animationDelay: '0.2s' }}>
              Designing Spaces<br />That Shape Tomorrow.
            </h1>
            <div className="flex flex-col md:flex-row md:items-center gap-16 fade-in" style={{ animationDelay: '0.3s' }}>
              <p className="text-sm md:text-base uppercase tracking-[0.2em] text-gray-300 max-w-sm leading-relaxed">
                A Mumbai-based architecture & interior design studio led by Priyank Mehta.
              </p>
              <Link
                to="/contact"
                className="inline-block bg-[#E7C665] text-[#1B2E24] px-16 py-7 text-sm font-black uppercase tracking-widest hover:bg-white transition-all shadow-2xl"
              >
                Start Your Project
              </Link>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-16 right-16 hidden md:flex flex-col items-end">
            <div className="w-48 h-px bg-[#E7C665]/40 mb-6" />
            <p className="text-[10px] uppercase tracking-[0.4em] text-[#E7C665] font-bold">Studio PM — Mumbai HQ</p>
        </div>
      </section>

      {/* Diversity Section - Aligned Editorial Grid with User-Requested Images */}
      <section className="py-32 md:py-64">
        <div className="container mx-auto px-6 md:px-12">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-24 lg:gap-40 items-start">
                {/* Left Text */}
                <div className="lg:col-span-5">
                    <span className="text-[#E7C665] font-black text-xs uppercase tracking-[0.3em]">Our Breadth</span>
                    <h2 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mt-12 mb-16 leading-none">
                      Architecture <br />Without Borders.
                    </h2>
                    <p className="text-lg md:text-2xl editorial-text text-[#1B2E24]/80 max-w-lg mb-20 leading-relaxed font-light">
                        From luxury villas and high-end residential interiors to corporate offices and boutique hospitality projects, Studio PM brings architectural rigor to every scale.
                    </p>
                    <Link to="/projects" className="inline-block text-sm font-black uppercase tracking-widest border-b-2 border-[#1B2E24] pb-4 hover:text-[#E7C665] hover:border-[#E7C665] transition-all">
                        Explore Our Portfolio
                    </Link>
                </div>
                
                {/* Right Grid - Balanced Alignment featuring requested imagery */}
                <div className="lg:col-span-7 grid grid-cols-2 gap-8 md:gap-12">
                    <div className="space-y-8 md:space-y-12">
                      {/* Image 2 Context: Residential Swing */}
                      <div className="overflow-hidden bg-white aspect-[3/4] shadow-xl group">
                        <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000 group-hover:scale-105" alt="Residential Interior Swing" />
                      </div>
                      {/* Image 3 Context: Floral Mural Hospitality */}
                      <div className="overflow-hidden bg-white aspect-square shadow-xl group">
                        <img src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000 group-hover:scale-105" alt="Hospitality Floral Concept" />
                      </div>
                    </div>
                    <div className="space-y-8 md:space-y-12 mt-16 md:mt-32">
                      {/* Image 4 Context: Glass Partition Office */}
                      <div className="overflow-hidden bg-white aspect-square shadow-xl group">
                        <img src="https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000 group-hover:scale-105" alt="Modern Glass Office" />
                      </div>
                      <div className="overflow-hidden bg-white aspect-[3/4] shadow-xl group">
                        <img src="https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000 group-hover:scale-105" alt="Luxury Retail" />
                      </div>
                    </div>
                </div>
            </div>
        </div>
      </section>

      {/* Featured Juhu Residence */}
      <section className="py-32 md:py-64 bg-[#1B2E24] text-white">
        <div className="container mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-24 lg:gap-40 items-center">
            <div className="col-span-12 lg:col-span-7 relative group">
                <div className="aspect-[16/10] overflow-hidden bg-gray-900 shadow-[0_50px_100px_rgba(0,0,0,0.5)]">
                    <img 
                        src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1600" 
                        alt="Juhu Residence Interior" 
                        className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105 opacity-80" 
                    />
                </div>
                <div className="absolute -bottom-12 -right-6 md:-bottom-24 md:-right-12 bg-[#E7C665] p-12 md:p-24 shadow-2xl z-20">
                    <span className="text-[10px] uppercase font-black text-[#1B2E24] tracking-[0.4em] block mb-6">Press Selection</span>
                    <h4 className="text-3xl md:text-6xl font-black text-[#1B2E24] leading-none tracking-tighter">Elle Decor India</h4>
                </div>
            </div>
            
            <div className="col-span-12 lg:col-span-5 lg:pl-16">
                <span className="text-[#E7C665] font-black text-xs uppercase tracking-[0.3em]">Iconic Project</span>
                <h2 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mt-12 mb-16 leading-none">A Timeless <br />Sanctuary.</h2>
                <p className="text-lg md:text-2xl text-gray-400 leading-relaxed editorial-text mb-20 font-light">
                    A Juhu project that defines our residential philosophy, balancing modernist silhouettes with tactile materials.
                </p>
                <Link to="/blog" className="inline-flex items-center space-x-12 group">
                    <span className="bg-white text-[#1B2E24] px-16 py-7 text-xs font-black uppercase tracking-widest group-hover:bg-[#E7C665] transition-all transform group-hover:-translate-y-1">
                        Read Narrative
                    </span>
                    <div className="hidden md:block w-32 h-px bg-[#E7C665] group-hover:w-48 transition-all duration-500" />
                </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Hospitality Section - Updated with Image 1 Context: Warm Bistro aesthetic */}
      <section className="py-32 md:py-64 bg-[#F4F1EA]">
        <div className="container mx-auto px-6 md:px-12">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-24 lg:gap-40 items-center">
                <div className="col-span-12 lg:col-span-5 order-2 lg:order-1">
                    <span className="text-[#E7C665] font-black text-xs uppercase tracking-[0.3em]">Hospitality Expertise</span>
                    <h2 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mt-12 mb-16 leading-none">The Urban <br />Bistro.</h2>
                    <p className="text-lg md:text-2xl text-[#1B2E24]/70 leading-relaxed editorial-text mb-20 font-light">
                        Our hospitality designs focus on the art of atmosphere. This bistro project integrates warm textures, arched steel windows, and tailored lighting to create an immersive dining experience.
                    </p>
                    <Link to="/projects" className="inline-block text-xs font-black uppercase tracking-widest bg-[#1B2E24] text-white px-16 py-7 hover:bg-[#E7C665] hover:text-[#1B2E24] transition-all shadow-xl">
                        View Project Details
                    </Link>
                </div>
                <div className="col-span-12 lg:col-span-7 order-1 lg:order-2">
                    <div className="relative aspect-[16/10] overflow-hidden group shadow-[0_50px_100px_rgba(0,0,0,0.15)] bg-[#1B2E24]">
                        <img 
                            src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=1600" 
                            alt="Warm Bistro Interior Project" 
                            className="w-full h-full object-cover transition-all duration-1000 group-hover:scale-105" 
                        />
                        <div className="absolute inset-0 bg-[#1B2E24]/5 pointer-events-none" />
                    </div>
                </div>
            </div>
        </div>
      </section>

      {/* Services Snapshot */}
      <section className="py-32 md:py-64 bg-[#1B2E24] text-white">
        <div className="container mx-auto px-6 md:px-12">
            <div className="flex flex-col md:flex-row justify-between items-baseline mb-32 gap-12">
                <h2 className="text-6xl md:text-9xl font-black tracking-tighter leading-none">Holistic <br />Services.</h2>
                <Link to="/services" className="text-xs font-black uppercase tracking-widest border-b-2 border-[#E7C665] pb-4 hover:border-white transition-all">
                  Full Capabilities
                </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16 lg:gap-24">
                {SERVICES.slice(0, 3).map((service, index) => (
                    <div key={service.id} className="group flex flex-col">
                        <div className="aspect-[3/4] overflow-hidden mb-16 bg-[#F4F1EA] shadow-2xl">
                            <img 
                                src={service.image} 
                                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000 group-hover:scale-110" 
                                alt={service.title} 
                            />
                        </div>
                        <div className="flex justify-between items-start mb-10 border-b border-white/10 pb-8">
                          <h4 className="text-4xl font-black tracking-tight leading-none">{service.title}</h4>
                          <span className="text-[12px] font-black text-[#E7C665] tracking-[0.4em]">0{index + 1}</span>
                        </div>
                        <p className="text-lg text-gray-400 leading-relaxed max-w-sm editorial-text font-light">
                          {service.description}
                        </p>
                    </div>
                ))}
            </div>
        </div>
      </section>
    </main>
  );
};

export default Home;
