
import React, { useState } from 'react';
import { PROJECTS } from '../constants';

const Projects: React.FC = () => {
  const [filter, setFilter] = useState('All');
  const categories = ['All', 'Residential', 'Hospitality', 'Office', 'Villa', 'Retail'];

  const filteredProjects = filter === 'All' 
    ? PROJECTS 
    : PROJECTS.filter(p => p.category === filter);

  return (
    <main className="pt-32 bg-[#F4F1EA] min-h-screen pb-32">
      <section className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
            <h1 className="text-7xl md:text-9xl font-bold tracking-tighter leading-none">Archive<span className="text-[#E7C665]">.</span></h1>
            <div className="flex flex-wrap gap-4">
                {categories.map(cat => (
                    <button 
                        key={cat} 
                        onClick={() => setFilter(cat)}
                        className={`px-6 py-2 border rounded-full text-xs font-bold uppercase tracking-widest transition-all ${filter === cat ? 'bg-[#1B2E24] text-white border-[#1B2E24]' : 'bg-transparent text-[#1B2E24] border-[#1B2E24]/20 hover:border-[#1B2E24]'}`}
                    >
                        {cat}
                    </button>
                ))}
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {filteredProjects.map((project) => (
                <div key={project.id} className="group cursor-pointer">
                    <div className="relative aspect-video overflow-hidden mb-6">
                        <img 
                            src={project.image} 
                            alt={project.title} 
                            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" 
                        />
                        <div className="absolute top-6 left-6 bg-[#E7C665] text-[#1B2E24] px-4 py-1 text-[10px] font-bold uppercase tracking-widest">
                            {project.category}
                        </div>
                    </div>
                    <div className="flex justify-between items-start">
                        <div>
                            <h3 className="text-3xl font-bold mb-2">{project.title}</h3>
                            <p className="text-sm text-[#1B2E24]/60">{project.description}</p>
                        </div>
                        <div className="w-10 h-10 rounded-full border border-[#1B2E24]/10 flex items-center justify-center group-hover:bg-[#1B2E24] group-hover:text-white transition-all">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
                        </div>
                    </div>
                </div>
            ))}
        </div>
      </section>
    </main>
  );
};

export default Projects;
