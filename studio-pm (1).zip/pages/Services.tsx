
import React from 'react';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  return (
    <main className="pt-32 bg-[#F4F1EA]">
      <section className="container mx-auto px-6 md:px-12 pb-20">
        <h1 className="text-7xl md:text-9xl font-bold tracking-tighter leading-none mb-16">
          Expertise<span className="text-[#E7C665]">.</span>
        </h1>
        <p className="max-w-2xl text-xl leading-relaxed italic text-[#1B2E24]/80 mb-24">
            From the initial conceptual sketches to the final turnkey handover, Studio PM offers a holistic design experience tailored for luxury residential living.
        </p>

        <div className="space-y-32">
          {SERVICES.map((service, index) => (
            <div key={service.id} className={`grid grid-cols-1 md:grid-cols-12 gap-12 items-center ${index % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}>
              <div className={`col-span-12 md:col-span-7 ${index % 2 !== 0 ? 'md:order-2' : ''}`}>
                <div className="aspect-video overflow-hidden">
                  <img src={service.image} alt={service.title} className="w-full h-full object-cover transition-transform duration-1000 hover:scale-105" />
                </div>
              </div>
              <div className={`col-span-12 md:col-span-5 flex flex-col justify-center ${index % 2 !== 0 ? 'md:order-1' : ''}`}>
                <span className="text-[#E7C665] font-bold text-xs uppercase tracking-widest mb-4">0{index + 1}</span>
                <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tighter">{service.title}</h2>
                <p className="text-sm text-[#1B2E24]/70 leading-relaxed editorial-text mb-10">
                  {service.description} Our approach ensures that every project is technically sound, aesthetically superior, and deeply personal. We manage all complexities so you can enjoy the creative journey.
                </p>
                <div>
                    <button className="bg-[#E7C665] text-[#1B2E24] px-8 py-4 text-xs font-bold uppercase tracking-widest hover:bg-[#1B2E24] hover:text-white transition-all">
                        Inquire About This Service
                    </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Process Section */}
      <section className="py-32 bg-[#1B2E24] text-white">
        <div className="container mx-auto px-6 md:px-12">
            <h2 className="text-4xl md:text-6xl font-bold tracking-tighter mb-20">The Studio PM <span className="text-[#E7C665]">Process</span></h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                {[
                    { step: '01', title: 'Consultation', text: 'Understanding your vision, lifestyle requirements, and site potential.' },
                    { step: '02', title: 'Conceptualization', text: 'Developing architectural layouts, material palettes, and design language.' },
                    { step: '03', title: 'Design Development', text: 'Detailed 3D visualizations, technical drawings, and precise specifications.' },
                    { step: '04', title: 'Execution', text: 'On-site management, quality control, and final bespoke styling.' }
                ].map((p) => (
                    <div key={p.step} className="p-8 border border-white/10 hover:border-[#E7C665] transition-all group">
                        <span className="text-4xl font-bold text-[#E7C665]/20 group-hover:text-[#E7C665] transition-all mb-6 block">{p.step}</span>
                        <h4 className="text-lg font-bold mb-4">{p.title}</h4>
                        <p className="text-xs text-gray-400 leading-relaxed">{p.text}</p>
                    </div>
                ))}
            </div>
        </div>
      </section>
    </main>
  );
};

export default Services;
