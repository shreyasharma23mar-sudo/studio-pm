
import { Project, Service, BlogPost } from './types';

export const COLORS = {
  primary: '#1B2E24', // Deep Green
  accent: '#E7C665',  // Soft Yellow
  neutral: '#F4F1EA', // Bone White
};

export const PROJECTS: Project[] = [
  {
    id: 'res-juhu',
    title: 'A Timeless Home',
    category: 'Residential',
    image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=1200',
    description: 'A Juhu residence featured in Elle Decor India, showcasing minimalist sensibilities and opulent materials.'
  },
  {
    id: 'hosp-bistro',
    title: 'The Urban Bistro',
    category: 'Hospitality',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=1200',
    description: 'Restaurant architecture focusing on intimate lighting, arched steel windows, and raw material honesty.'
  },
  {
    id: 'res-swing',
    title: 'The Gaothan Loft',
    category: 'Residential',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200',
    description: 'A contemporary residential space featuring bespoke hanging elements and high-end marble finishes.'
  },
  {
    id: 'hosp-floral',
    title: 'The Botanist Cafe',
    category: 'Hospitality',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=1200',
    description: 'An immersive hospitality environment with exposed timber beams and hand-painted floral narratives.'
  },
  {
    id: 'off-nexus',
    title: 'Nexus Corporate HQ',
    category: 'Office',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1200',
    description: 'Office design & planning centered around glass-partitioned collaborative zones and natural lighting.'
  }
];

export const SERVICES: Service[] = [
  {
    id: 'arch',
    title: 'Architecture Design',
    description: 'From villas to hotels, we design structures that harmonize with their context.',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'interior',
    title: 'Interior Design',
    description: 'Curation of soul-stirring residential and commercial spaces.',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'office',
    title: 'Office Planning',
    description: 'Research-driven spatial layouts for modern productivity and collaboration.',
    image: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'hosp',
    title: 'Hospitality & Hotels',
    description: 'Creating memorable experiences through restaurant and hotel architecture.',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'turnkey',
    title: 'Turnkey Solutions',
    description: 'Complete project management from conceptualization to final styling.',
    image: 'https://images.unsplash.com/photo-1503387762-592dea58ef23?auto=format&fit=crop&q=80&w=800'
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'research-design',
    title: 'The Role of Research in Modern Architecture',
    category: 'Insights',
    date: 'April 2024',
    image: 'https://images.unsplash.com/photo-1497215842964-222b430dc094?auto=format&fit=crop&q=80&w=1200',
    excerpt: 'How Priyank Mehta and the Studio PM team approach site-specific research before sketching.'
  },
  {
    id: 'elle-decor-feature',
    title: 'Juhu Residence: A Study in Timelessness',
    category: 'Press',
    date: 'March 2024',
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1200',
    excerpt: 'The Elle Decor India feature showcases our balance of minimalist sensibilities with opulent materials.'
  }
];
